# ML Practicals List

1. Dimensionality Reduction using PCA Algorithm for Wine Classification.

2. Regression Analysis for Predicting Uber Ride Prices.

3. Classification Analysis using Support Vector Machines (SVM) for Handwritten Digit Classification.

4. Implement K-Means clustering on Iris.csv dataset. Determine the number of clusters using the elbow method.

5. Implement Random Forest Classifier model to predict the safety of the car.
